-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s12p31a205
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `space_id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`category_id`),
  KEY `FKj5t0d1np3ejgledbpb1tbb3c5` (`space_id`),
  CONSTRAINT `FKj5t0d1np3ejgledbpb1tbb3c5` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`space_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,1,'기본'),(2,1,'test'),(3,3,'기본'),(5,7,'기본'),(6,9,'기본'),(7,11,'기본'),(8,11,'하이'),(9,13,'기본'),(10,13,'12기 자율 프로젝트'),(11,16,'기본'),(12,19,'기본');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `copy_sheets`
--

DROP TABLE IF EXISTS `copy_sheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `copy_sheets` (
  `copy_sheet_id` int(11) NOT NULL AUTO_INCREMENT,
  `copy_song_id` int(11) NOT NULL,
  `part` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `sheet_url` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`copy_sheet_id`),
  KEY `FKfenvx3evuwjnp0lr35lxyffcg` (`copy_song_id`),
  CONSTRAINT `FKfenvx3evuwjnp0lr35lxyffcg` FOREIGN KEY (`copy_song_id`) REFERENCES `copy_songs` (`copy_song_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `copy_sheets`
--

LOCK TABLES `copy_sheets` WRITE;
/*!40000 ALTER TABLE `copy_sheets` DISABLE KEYS */;
INSERT INTO `copy_sheets` VALUES (1,1,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1drum.musicxml'),(2,1,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1guitar.musicxml'),(3,1,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1vocal.musicxml'),(4,1,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1bass.musicxml'),(5,2,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1drum.musicxml'),(6,2,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1guitar.musicxml'),(7,2,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1vocal.musicxml'),(8,2,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1bass.musicxml'),(9,3,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s2drum.musicxml'),(10,3,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s2guitar.musicxml'),(11,3,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s2vocal.musicxml'),(12,3,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s2bass.musicxml'),(13,4,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1drum.musicxml'),(14,4,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1guitar.musicxml'),(15,4,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1vocal.musicxml'),(16,4,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1bass.musicxml'),(17,5,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1drum.musicxml'),(18,5,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1guitar.musicxml'),(19,5,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1vocal.musicxml'),(20,5,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s1bass.musicxml'),(21,6,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s2drum.musicxml'),(22,6,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s2guitar.musicxml'),(23,6,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s2vocal.musicxml'),(24,6,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s2bass.musicxml'),(25,7,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s27drum.musicxml'),(26,7,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s27guitar.musicxml'),(27,7,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s27vocal.musicxml'),(28,7,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s27bass.musicxml'),(29,8,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s7drum.musicxml'),(30,8,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s7guitar.musicxml'),(31,8,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s7vocal.musicxml'),(32,8,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s7bass.musicxml'),(33,9,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s9drum.musicxml'),(34,9,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s9guitar.musicxml'),(35,9,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s9vocal.musicxml'),(36,9,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_sheets/s9bass.musicxml');
/*!40000 ALTER TABLE `copy_sheets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `copy_songs`
--

DROP TABLE IF EXISTS `copy_songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `copy_songs` (
  `category_id` int(11) NOT NULL,
  `copy_song_id` int(11) NOT NULL AUTO_INCREMENT,
  `original_song_id` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `thumbnail_url` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`copy_song_id`),
  KEY `FKn69cmxte6t5cdx1jukq52pog0` (`category_id`),
  KEY `FKaxtj71qs1clsht5v94oitunu6` (`original_song_id`),
  CONSTRAINT `FKaxtj71qs1clsht5v94oitunu6` FOREIGN KEY (`original_song_id`) REFERENCES `original_songs` (`song_id`),
  CONSTRAINT `FKn69cmxte6t5cdx1jukq52pog0` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `copy_songs`
--

LOCK TABLES `copy_songs` WRITE;
/*!40000 ALTER TABLE `copy_songs` DISABLE KEYS */;
INSERT INTO `copy_songs` VALUES (1,1,1,'수정도 되는지 확인~~','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_thumbnails/i1.png'),(1,2,1,'ㅁㄴㅇㄹ','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/copy_thumbnails/i2.png'),(3,3,1,'ㅁㄴㅇㄹ','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/-n-U1yVh8fE.jpg'),(2,4,1,'ㅁㄴㅇㄹ','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/-n-U1yVh8fE.jpg'),(1,5,1,'수정도 되는지 확인~~','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/-n-U1yVh8fE.jpg'),(2,6,1,'ㅁㄴㅇㄹ','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/-n-U1yVh8fE.jpg'),(7,7,1,'너라는 별','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/-n-U1yVh8fE.jpg'),(11,8,1,'너라는 별','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/-n-U1yVh8fE.jpg'),(7,9,3,'에궁','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/NgEaOJ7lRWY.jpg');
/*!40000 ALTER TABLE `copy_songs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drawings`
--

DROP TABLE IF EXISTS `drawings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drawings` (
  `copy_sheet_id` int(11) NOT NULL,
  `drawing_id` int(11) NOT NULL AUTO_INCREMENT,
  `x` double NOT NULL,
  `y` double NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`drawing_id`),
  KEY `FKr8ps88yf834l69tjx51v9ks12` (`copy_sheet_id`),
  CONSTRAINT `FKr8ps88yf834l69tjx51v9ks12` FOREIGN KEY (`copy_sheet_id`) REFERENCES `copy_sheets` (`copy_sheet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drawings`
--

LOCK TABLES `drawings` WRITE;
/*!40000 ALTER TABLE `drawings` DISABLE KEYS */;
/*!40000 ALTER TABLE `drawings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `original_sheets`
--

DROP TABLE IF EXISTS `original_sheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `original_sheets` (
  `sheets_id` int(11) NOT NULL AUTO_INCREMENT,
  `song_id` int(11) NOT NULL,
  `part` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `sheet_url` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`sheets_id`),
  KEY `FKnjwywdamnqejmgyy54eqdmii7` (`song_id`),
  CONSTRAINT `FKnjwywdamnqejmgyy54eqdmii7` FOREIGN KEY (`song_id`) REFERENCES `original_songs` (`song_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `original_sheets`
--

LOCK TABLES `original_sheets` WRITE;
/*!40000 ALTER TABLE `original_sheets` DISABLE KEYS */;
INSERT INTO `original_sheets` VALUES (1,1,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/original_sheets/sheet_-n-U1yVh8fE_drum.musicxml'),(2,1,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/original_sheets/sheet_-n-U1yVh8fE_guitar.musicxml'),(3,1,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/original_sheets/sheet_-n-U1yVh8fE_guitar.musicxml'),(4,1,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/original_sheets/sheet_-n-U1yVh8fE_bass.musicxml'),(5,2,'drum','test'),(6,2,'guitar','test'),(7,2,'vocal','test'),(8,2,'bass','test'),(9,3,'drum','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/original_sheets/sheet_NgEaOJ7lRWY_drum.musicxml'),(10,3,'guitar','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/original_sheets/sheet_NgEaOJ7lRWY_guitar.musicxml'),(11,3,'vocal','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/original_sheets/sheet_NgEaOJ7lRWY_guitar.musicxml'),(12,3,'bass','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/original_sheets/sheet_NgEaOJ7lRWY_bass.musicxml');
/*!40000 ALTER TABLE `original_sheets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `original_songs`
--

DROP TABLE IF EXISTS `original_songs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `original_songs` (
  `bpm` smallint(6) NOT NULL,
  `song_id` int(11) NOT NULL AUTO_INCREMENT,
  `total_measures` smallint(6) NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `thumbnail_url` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `youtube_url` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`song_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `original_songs`
--

LOCK TABLES `original_songs` WRITE;
/*!40000 ALTER TABLE `original_songs` DISABLE KEYS */;
INSERT INTO `original_songs` VALUES (83,1,62,'-n-U1yVh8fE','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/-n-U1yVh8fE.jpg','https://www.youtube.com/watch?v=-n-U1yVh8fE&pp=ygUN64SI652864qUIOuzhA%3D%3D'),(120,2,65,'너라는 별','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/-n-U1yVh8fE.jpg','test'),(151,3,98,'NgEaOJ7lRWY','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/thumbnails/NgEaOJ7lRWY.jpg','NgEaOJ7lRWY');
/*!40000 ALTER TABLE `original_songs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spaces`
--

DROP TABLE IF EXISTS `spaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `spaces` (
  `space_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_bin DEFAULT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `share_key` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `type` enum('PERSONAL','TEAM') COLLATE utf8mb4_bin NOT NULL DEFAULT 'PERSONAL',
  PRIMARY KEY (`space_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spaces`
--

LOCK TABLES `spaces` WRITE;
/*!40000 ALTER TABLE `spaces` DISABLE KEYS */;
INSERT INTO `spaces` VALUES (1,'2025-01-01 10:00:00.000000',NULL,'ㅅㄷㄴㅅ','ㅅㄷㄴㅅ',NULL,NULL,'PERSONAL'),(2,'2025-01-01 10:00:00.000000',NULL,'team','ㅅㄷㄴㅅteam',NULL,NULL,'TEAM'),(3,'2025-05-21 22:02:01.567568',NULL,'ㅅㄷㄴㅅ','이래도 와야 해~',NULL,'6b2c9126-e754-4e80-8239-379a41f55ad3','TEAM'),(4,'2025-05-21 23:33:01.164401',NULL,'만들기 테스트','되는가?','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/space_images/space_id/4image/webp','11663788-4c11-4786-9cf2-7cd7fdd58498','TEAM'),(5,'2025-05-22 01:35:31.295389',NULL,NULL,NULL,NULL,NULL,'PERSONAL'),(6,'2025-05-22 03:05:46.987202',NULL,NULL,NULL,NULL,NULL,'PERSONAL'),(7,'2025-05-22 03:42:15.481609',NULL,'test','뭐야 왜 비어 있어',NULL,'de41709b-c020-4a38-8aae-8ef52b02dcf8','TEAM'),(8,'2025-05-22 04:07:25.491946',NULL,NULL,NULL,NULL,NULL,'PERSONAL'),(9,'2025-05-22 04:16:05.406766',NULL,'비트윈','비트윈이에요',NULL,'2ac341ca-5756-4001-8815-ea0175eecc28','TEAM'),(10,'2025-05-22 04:23:15.544706',NULL,NULL,NULL,NULL,NULL,'PERSONAL'),(11,'2025-05-22 04:26:06.809388',NULL,'비트윈','비트윈',NULL,'2c07ad87-eaab-4c19-8c5b-52cc9bfaf295','TEAM'),(12,'2025-05-22 04:30:31.189224',NULL,NULL,NULL,NULL,NULL,'PERSONAL'),(13,'2025-05-22 05:48:53.539038',NULL,'A205 BEATWEEN','더욱 편한 합주를 위한 합주 서비스입니다.\r\nAI를 통한 자동 악보 생성과 악보의 동기화 재생 기능을 제공합니다.','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/space_images/si13.png','8a4eff50-1ac2-4c0a-9243-6c1e449a8609','TEAM'),(14,'2025-05-22 06:24:05.665263',NULL,NULL,NULL,NULL,NULL,'PERSONAL'),(15,'2025-05-22 06:29:49.044034',NULL,NULL,NULL,NULL,NULL,'PERSONAL'),(16,'2025-05-22 09:25:34.735777',NULL,'우리밴드','짱짱',NULL,'8cc38ba4-84a4-4582-9ab6-53304cbca5f2','TEAM'),(17,'2025-05-22 09:37:09.579602',NULL,NULL,NULL,NULL,NULL,'PERSONAL'),(18,'2025-05-22 09:46:00.173915',NULL,'','','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/space_images/si18.png',NULL,'PERSONAL'),(19,'2025-05-22 10:01:32.482310',NULL,'123132','12312','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/space_images/si19.png','20104015-f834-49d0-8c35-e749f648320a','TEAM');
/*!40000 ALTER TABLE `spaces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `nickname` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `profile_image_url` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `status` enum('ACTIVE','DELETED') COLLATE utf8mb4_bin NOT NULL DEFAULT 'ACTIVE',
  `social_login_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'2025-05-21 21:56:00.503528',NULL,NULL,'구리구리구리구리가위바위보','kllee0309@gmail.com','1234',NULL,'ACTIVE',''),(2,'2025-05-21 21:30:45.000000',NULL,NULL,'test','test','test','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/user_images/user1.png','ACTIVE',''),(3,'2025-05-22 01:17:13.107417',NULL,NULL,'유저3스페이스5','유저3스페이스5','1234',NULL,'ACTIVE',NULL),(4,'2025-05-22 01:35:31.206486',NULL,NULL,'유저4스페이스5','유저4스페이스5','1234',NULL,'ACTIVE',NULL),(5,'2025-05-22 03:05:46.873197',NULL,NULL,'asdf','test@test.com','test',NULL,'ACTIVE',NULL),(6,'2025-05-22 04:07:25.430839',NULL,NULL,'망곰','jjkkgh@naver.com','sopnng12@',NULL,'ACTIVE',NULL),(7,'2025-05-22 04:23:15.388101',NULL,NULL,'qw','qw@qw.com','qw',NULL,'ACTIVE',NULL),(8,'2025-05-22 04:30:31.131899',NULL,NULL,'asdf11','ssafy@gmail.com','ssafy','https://a205-beatween-bucket.s3.ap-northeast-2.amazonaws.com/user_images/user8.png','ACTIVE',NULL),(9,'2025-05-22 06:24:05.566652',NULL,NULL,'kyuli','kyuli','1234',NULL,'ACTIVE',NULL),(10,'2025-05-22 06:29:49.003846',NULL,NULL,'kyufdsfdsi','era567ㄴㅇㄹㅇㄴ5','1234',NULL,'ACTIVE',NULL),(11,'2025-05-22 09:37:09.533648',NULL,NULL,'admin','admin@admin.com','admin',NULL,'ACTIVE',NULL),(12,'2025-05-22 09:46:00.132902',NULL,NULL,'resd','dkanfjgwls@naver.com','dkanfjgwls2',NULL,'ACTIVE',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_spaces`
--

DROP TABLE IF EXISTS `users_spaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_spaces` (
  `user_space_id` int(11) NOT NULL AUTO_INCREMENT,
  `role` enum('OWNER','MEMBER') COLLATE utf8mb4_bin NOT NULL DEFAULT 'OWNER',
  `space_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`user_space_id`),
  KEY `FK8hjasr0kcig71ujpmfxte9atc` (`space_id`),
  KEY `FKlbqm6dliaje58i9yplkqiq4as` (`user_id`),
  CONSTRAINT `FK8hjasr0kcig71ujpmfxte9atc` FOREIGN KEY (`space_id`) REFERENCES `spaces` (`space_id`),
  CONSTRAINT `FKlbqm6dliaje58i9yplkqiq4as` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_spaces`
--

LOCK TABLES `users_spaces` WRITE;
/*!40000 ALTER TABLE `users_spaces` DISABLE KEYS */;
INSERT INTO `users_spaces` VALUES (1,'OWNER',1,1),(2,'MEMBER',1,2),(3,'OWNER',3,1),(5,'OWNER',5,4),(6,'OWNER',6,5),(7,'OWNER',7,5),(8,'OWNER',8,6),(9,'OWNER',9,6),(10,'OWNER',10,7),(11,'OWNER',11,7),(12,'OWNER',12,8),(13,'MEMBER',11,4),(14,'OWNER',13,8),(15,'OWNER',14,9),(16,'OWNER',15,10),(17,'MEMBER',11,8),(18,'OWNER',16,7),(19,'OWNER',17,11),(20,'OWNER',18,12),(21,'OWNER',19,12);
/*!40000 ALTER TABLE `users_spaces` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-22 12:36:25
